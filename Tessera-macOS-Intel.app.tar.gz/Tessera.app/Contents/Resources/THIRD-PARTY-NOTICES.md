# Third-party notices

Tessera bundles or depends on the following software.

## Eclipse LemMinX — XML language server (bundled as `lemminx`)

- Used for XML Schema, DTD and RELAX NG validation, schema-aware completion and hover documentation.
- License: Eclipse Public License 2.0 (EPL-2.0), https://www.eclipse.org/legal/epl-2.0/
- Source code: https://github.com/eclipse/lemminx
- Native builds are published by Red Hat with the VS Code XML extension: https://github.com/redhat-developer/vscode-xml/releases

LemMinX is distributed unmodified, as a separate executable. Its source code is available from the repository above under the EPL-2.0.

## Other libraries

The app also uses open-source Rust crates and npm packages under MIT, Apache-2.0, ISC and similar permissive licenses, including Tauri, CodeMirror, Svelte, Lucide icons (ISC), roxmltree, quick-xml, xee-xpath/xot (MIT), encoding_rs and serde. See `Cargo.lock` and `package-lock.json` for the full lists.
